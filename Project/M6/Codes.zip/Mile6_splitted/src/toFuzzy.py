#!/usr/bin/env python

#########################################################################################################
#Import the required libraries:
import rospy
from geometry_msgs.msg import Twist,Pose
from nav_msgs.msg import Odometry
import numpy as np
import math
import sympy as sym
from sympy import *
import skfuzzy as fuzz
from skfuzzy import control as ctrl
#########################################################################################################

#########################################################################################################

#######################################################################
#Initialize ROS Node
rospy.init_node('Fuzzy_Rob_2D', anonymous=True) #Identify ROS Node
#####################################################################

#######################################################################
#ROS Publisher Code for Velocity
pub1 = rospy.Publisher('/cmd_vel', Twist, queue_size=10) #Identify the publisher "pub1" to publish on topic "/cmd_vel" to send message of type "Twist"
vel_msg = Twist() #Identify msg variable of data type Twist
rate = rospy.Rate(10) # rate of publishing msg 10hz
#######################################################################

#######################################################################
def quaternion_to_euler(x, y, z, w):
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(t0, t1)
    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    pitch = math.asin(t2)
    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(t3, t4)
    return [yaw, pitch, roll]
#######################################################################

#######################################################################
#ROS Subscriber Code for Position
flag_cont = 0	#Initialize flag by zero
pos_msg = Pose()	#Identify msg variable of data type Pose
position = np.zeros((1,6))
Velocity_msg = Twist()
velocity = np.zeros((1,6))
#######################################################################
 
#######################################################################
#Define the initial pose and velocity of the vehicle


x_p = 0.0
y_p = 0.0
vel_p_x =0.0#*cos(Rob_pos_0[2])
vel_p_y = 0.0#*sin(Rob_pos_0[2])
#######################################################################

#########################################################################################################

#########################################################################################################
x_actual_filtered = 0.0
y_actual_filtered = 0.0
theta_actual_filtered = 0.0
x_goal_rec=0.0
y_goal_rec=0.0
flag_cont_igot = 0
flag_i_exit_loop = 0
def Received_values(msg):
    global x_actual_filtered
    global y_actual_filtered
    global theta_actual_filtered
    global flag_cont_igot
    global x_goal_rec
    global y_goal_rec
    global flag_i_exit_loop
    x_actual_filtered = msg.position.x
    y_actual_filtered = msg.position.y
    theta_actual_filtered = msg.orientation.x
    #i now got filtered actual pose and below i get the goal to go
    x_goal_rec = msg.position.z
    y_goal_rec = msg.orientation.w
    flag_i_exit_loop = msg.orientation.z  # Master will make it 1 when it finsihes there 
    flag_cont_igot = 1
subx = rospy.Subscriber("/Xs_Ys_ToFuzzy", Pose, Received_values)
#subscribe actual filtered and goal x and y values



#########################################################################################################
## Fuzzy Implementation
def Fuzzy_Ctrl(Goal_pos,Act_pos):
	# New Antecedent/Consequent objects hold universe variables and membership functions
	Distance = ctrl.Antecedent(np.arange(0, 100+0.1, 0.1), 'Distance') #Input
	Angle = ctrl.Antecedent(np.arange(-np.pi, np.pi+0.001, 0.001), 'Angle') #Input

	Velocity = ctrl.Consequent(np.arange(-0.13, 0.26+0.13+0.01, 0.01), 'Velocity') #Output
	Omega = ctrl.Consequent(np.arange(-1.82-1.82-0.01, 1.82+1.82+0.01, 0.01), 'Omega') #Output

	# Auto-membership function population is possible with .automf(3, 5, or 7)
	#Distance.automf(5)
	#Velocity.automf(3)

	# Custom membership functions can be built interactively with a familiar, Pythonic API
	Distance['Near'] = fuzz.trimf(Distance.universe, [0, 0, 0.5])
	Distance['Mid'] = fuzz.trimf(Distance.universe, [0, 0.5, 1])
	Distance['Far'] = fuzz.trapmf(Distance.universe, [0.5, 1, 100, 100])

	Angle['Neg'] = fuzz.trapmf(Angle.universe, [-np.pi, -np.pi, -np.pi/4, 0])
	Angle['Zero'] = fuzz.trimf(Angle.universe, [-np.pi/4, 0, np.pi/4])
	Angle['Pos'] = fuzz.trapmf(Angle.universe, [0, np.pi/4, np.pi, np.pi])

	Velocity['Zero'] = fuzz.trimf(Velocity.universe, [-0.11, 0, 0.11])
	Velocity['Half'] = fuzz.trimf(Velocity.universe, [0, 0.11, 0.22])
	Velocity['Full'] = fuzz.trimf(Velocity.universe, [0.11, 0.22, 0.22+0.11])

	Omega['Negative'] = fuzz.trimf(Omega.universe, [-1.3-1.3, -1.3, 0])
	Omega['Zero'] = fuzz.trimf(Omega.universe, [-1.3, 0, 1.3])
	Omega['Positive'] = fuzz.trimf(Omega.universe, [0, 1.3, 1.3+1.3])

	# You can see how these look with .view()
	#Distance.view()
	#Angle.view()

	#Velocity.view()
	#Omega.view()

	#Identify Rules
	#rule0 = ctrl.Rule(antecedent=((Distance['nb'] & delta['nb']) |
	#                              (Distance['ns'] & delta['nb']) |
	#                              (Distance['nb'] & delta['ns'])),
	#                  consequent=output['nb'], label='rule nb')
	rule1 = ctrl.Rule(Angle['Neg'], Velocity['Zero'])
	rule2 = ctrl.Rule(Angle['Neg'], Omega['Negative'])
	rule3 = ctrl.Rule(Angle['Pos'], Velocity['Zero'])
	rule4 = ctrl.Rule(Angle['Pos'], Omega['Positive'])
	rule5 = ctrl.Rule(Angle['Zero'], Omega['Zero'])
	rule6 = ctrl.Rule(antecedent=((Distance['Near'] & Angle['Zero'])),
		          consequent=Velocity['Zero'])
	rule7 = ctrl.Rule(antecedent=((Distance['Mid'] & Angle['Zero'])),
		          consequent=Velocity['Half'])
	rule8 = ctrl.Rule(antecedent=((Distance['Far'] & Angle['Zero'])),
		          consequent=Velocity['Full'])

	Robot_ctrl = ctrl.ControlSystem([rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8])

	Motion = ctrl.ControlSystemSimulation(Robot_ctrl)

	# Pass inputs to the ControlSystem using Antecedent labels with Pythonic API
	# Note: if you like passing many inputs all at once, use .inputs(dict_of_data)
	dis = np.sqrt((Goal_pos[0]-Act_pos[0])**2+(Goal_pos[1]-Act_pos[1])**2)
	print('distance is',dis)
	Motion.input['Distance'] = dis
	global last
	ang = np.arctan2((Goal_pos[1]-Act_pos[1]),(Goal_pos[0]-Act_pos[0]))-Act_pos[2]
	while ang < last-np.pi: ang += 2*np.pi
	while ang > last+np.pi: ang -= 2*np.pi
	last = ang
	print('angle is',ang)
	Motion.input['Angle'] = ang

	# Crunch the numbers
	Motion.compute()

	print(Motion.output['Velocity'])
	#Velocity.view(sim=Motion)
	out1 = Motion.output['Velocity']

	print(Motion.output['Omega'])
	#Omega.view(sim=Motion)
	out2 = Motion.output['Omega']

	Cont_input = [out1,out2]
	print(Cont_input)
	return Cont_input
#########################################################################################################

#########################################################################################################
#######################################################################

tau = 0.1 #Sampling Time
rob_mass = 1 #Robot Mass (Turtlebot 3 Waffle_pi)
last = 0
v = 0.0
w = 0.0
while not rospy.is_shutdown(): 
    if flag_i_exit_loop ==1:
	break
    if (sqrt((x_actual_filtered - x_goal_rec )**2+(y_actual_filtered - y_goal_rec)**2) < 0.07)  : 
 	vel_msg.linear.x = 0 #Linear Velocity
        vel_msg.linear.y = 0
        vel_msg.linear.z = 0
        vel_msg.angular.x = 0
        vel_msg.angular.y = 0
        vel_msg.angular.z = 0 #Angular Velocity
    	#print('velocity is',v)
    	pub1.publish(vel_msg)	#Publish msg
    	rate.sleep()		#Sleep with rate
	 
    
    if flag_cont_igot ==1 :
	

	#Get Robot Current Position and Velocity
	Rob_pos = [x_actual_filtered,y_actual_filtered,theta_actual_filtered]
	
	#Rob_vel = [velocity[0],velocity[5]]
	Goal_Pos = [x_goal_rec,y_goal_rec]
	
	#Calculate the control effort from the fuzzy control
	Cont_input = Fuzzy_Ctrl(Goal_Pos,Rob_pos)
	v = round((Cont_input[0]),2) 	#Linear Velocity	
	w = round((Cont_input[1]),2)  	#Angular Velocity

        #Set the values of the Twist msg to be publeshed
        vel_msg.linear.x = v #Linear Velocity
        vel_msg.linear.y = 0
        vel_msg.linear.z = 0
        vel_msg.angular.x = 0
        vel_msg.angular.y = 0
        vel_msg.angular.z = w #Angular Velocity

	#Update the previous robot states for the next iteration
	vel_p_x = v*cos(Rob_pos[2])
	vel_p_y = v*sin(Rob_pos[2])
	x_p = Rob_pos[0]
	y_p = Rob_pos[1]
        flag_cont = 0
    else:
        #Set the values of the Twist msg to be publeshed
        vel_msg.linear.x = 0 #Linear Velocity
        vel_msg.linear.y = 0
        vel_msg.linear.z = 0
        vel_msg.angular.x = 0
        vel_msg.angular.y = 0
        vel_msg.angular.z = 0 #Angular Velocity
    #print('velocity is',v)
    pub1.publish(vel_msg)	#Publish msg
    rate.sleep()		#Sleep with rate

print ("00000000000000iam here000000000000 End Fuzzy")
vel_msg.linear.x = 0 #Linear Velocity
vel_msg.linear.y = 0
vel_msg.linear.z = 0  
vel_msg.angular.x = 0
vel_msg.angular.y = 0 
vel_msg.angular.z = 0 #Angular Velocity
pub1.publish(vel_msg)	#Publish msg
rospy.signal_shutdown("for plotting")
print ("00000000000000i finished End Fuzzy")

#########################################################################################################
