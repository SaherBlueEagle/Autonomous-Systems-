#!/usr/bin/env python
import numpy as np
from multiprocessing import Queue
import time
import sys
import os
import collections
from matplotlib import cm
from PIL import Image
from numpy import*
from scipy import ndimage
from PIL import Image, ImageOps
import matplotlib.pyplot as plt
import rospy
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import Point, Twist
from math import atan2
from math import sqrt
import cv2 #import openCV to python
### Libraries to be imported
import math
import tf #library used for states transformation from Quaternian to Euler and vice versa

from nav_msgs.msg import Odometry #import msg data type "Odometry" from nav_msgs dependency to be subscribed 
from geometry_msgs.msg import Twist, Pose #import msg data type "Twist" and "Pose" from geometry_msgs dependency to be published and subscribed
#####################################################################################################################################################################

import skfuzzy as fuzz
from skfuzzy import control as ctrl

i = -1 # are horizontal
j = 0  # are vertical
value = 0
matrix = np.zeros((400,1000))
matrix_outx = np.zeros((400,1000))

#img = Image.open('/home/saher/catkin_ws/src/Mile6_splitted/src/Input.png').convert('L')
#img_inverted = ImageOps.invert(img)

#np_img = np.array(img_inverted)
#np_img[np_img == 0] = 1 #not converted from 0 to 1 its converted to 0 and 255
# so above line remake the 0`s to 1 which is free space
# and the line below turns 255 into 0 which is obstacles
#np_img[np_img ==255] = 0
#np_img[np_img ==254] = 0
#matrix = np_img
#matrix_outx = np_img

img = cv2.imread('/home/saher/catkin_ws/src/Mile6_splitted/src/Input.png')  #Read image 
grayImage = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) #Convert RGB image to grayscale
ret, bw_img = cv2.threshold(grayImage,0,255,cv2.THRESH_BINARY) #Convert grayscale image to binary

bw_img = bw_img.astype(np.uint8)
matrix = bw_img
matrix_outx = bw_img
np_img = bw_img

np.set_printoptions(threshold=np.inf, linewidth=np.inf)  # turn off summarization, line-wrapping
with open('/home/saher/catkin_ws/src/Mile6_splitted/src/output2D_Valid_Arry.txt', 'w') as f:
    f.write(np.array2string(np_img))               
obstacles = ""
explored = ""
def is_obstacle(Cell_X,Cell_Y):
    if Cell_X <= 999 and Cell_Y <= 399 :
        valu = matrix[Cell_Y,Cell_X]
        if valu == 0:
            return True
    return False
def is_wall_cell(Cell_X,Cell_Y):
    if Cell_X == 0 and Cell_Y > 0:
        return True
    if Cell_X > 0 and Cell_Y == 0:
        return True
    if Cell_X == 0 and Cell_Y == 0:
        return True
    return False
def is_explored_cell(Cell_X,Cell_Y):
    if "i=" + str(Cell_X) in explored and "j=" + str(Cell_Y) in explored:
        return True
    return False
def add_explored_cell(Cel_X,Cel_Y):
    global explored
    str1 = "i=" + str(Cel_X)+ ","
    str2 = "j=" + str(Cel_Y)+ ","
    exploredx = str1+str2
    explored = explored + "".join(exploredx)
    return



def implement_BFS(start_point=[],goal_point=[]):
    global matrix
    var_queue = Queue()
    start_x = start_point[0]
    start_y = start_point[1]
    end_x = goal_point[0]
    end_y = goal_point[1]
    matrix[end_x,end_y] = 8 # <===== give a flag / Higlight the goal point (enha teba 8 fe west el 0s we el 1s)
    pth_list = bfs_helper(matrix, (start_x, start_y),(end_x,end_y))
    print("type now : " + str(type(pth_list)))
    return pth_list
  
    
 
for iter in range(1):
    start_x,start_y = 0,0 # 
def bfs_helper(grid, start,goalp):
    global matrix
    queue = collections.deque([[start]])
    goal = matrix[goalp[0],goalp[1]]
    height = len(matrix)
    width = len(matrix[0])
    print("Using BFS : " + str(width) + " X "  + str(height))
    print("Goal cell changed from 1 to value '8' for only Highlighting it => " + str(goal))
    seen = set([start])
    while queue:
        path = queue.popleft()
        x, y = path[-1]
        if grid[y][x] == goal:
            return path
        for x2, y2 in ((x,y+1) , (x,y-1), (x-1,y),(x+1,y),(x-1,y-1),(x+1,y+1),(x+1,y-1),(x-1,y+1)):
            if 0 <= x2 < width and 0 <= y2 < height and is_wall_cell(x2,y2)==False and is_obstacle(x2+24,y2+24)==False and is_obstacle(x2,y2+24)==False and is_obstacle(x2+24,y2)==False and is_obstacle(x2-24,y2)==False and is_obstacle(x2,y2-24)==False and is_obstacle(x2+24,y2-24)==False and is_obstacle(x2-24,y2+24)==False and (x2, y2) not in seen:
                queue.append(path + [(x2, y2)])
                seen.add((x2, y2))

#============================ MAIN BFS CALL ==========================
#++++++++++++++++++++++++++++
#=====================================================================
#=====================================================================
rospy.init_node("BFS_Kalman_Fuzzy")
BFSstart = time.time() #  <========= capture time before execution
startx = rospy.get_param("~x_Start")
my_start = [int(startx), int(rospy.get_param("~y_Start"))] # giving start position i,j    <=======================================    start point
 #Sampling Time
my_goal = [int(rospy.get_param("~y_Goal")), int(rospy.get_param("~x_Goal"))]  #[40, 640] # giving end position j,i<=======================================    goal point

path_arry_list = implement_BFS(my_start,my_goal) #<=================================== needed BFS method takes start and goal points only
turtleBotpath_points =  path_arry_list
length = len(path_arry_list)
print('============== Given Path Using BFS ==============')
for ipj in range(length):
    X_Previousath = path_arry_list[ipj][0]
    Y_Previousath = path_arry_list[ipj][1]
    matrix_outx[Y_Previousath,X_Previousath] = 0 
    print(" move in j : " +str(Y_Previousath) + " then " + "move in i : " +str(X_Previousath) ) 
matrix_outx[matrix_outx == 4] = 1  
matrix_outx[matrix_outx >4] = 130
BFSend = time.time()#  <========= capture time after execution
print ("Goal Reached ! , Time taken to find goal : " + str(BFSend-BFSstart))
np.set_printoptions(threshold=np.inf, linewidth=np.inf)
im = Image.fromarray(matrix_outx*255)
im.save("/home/saher/catkin_ws/src/Mile6_splitted/src/Output_BFS.png")
#=========================================BFS Writer==================================
with open('/home/saher/catkin_ws/src/Mile6_splitted/src/path_out_BFS.txt', 'w') as f:
    f.write(np.array2string(matrix_outx)) 
print ("Path Drawn from start to goal which cell value is '8'")
print ("Path saved to 'Output_BFS.png' in same Dir of .py file If On Windows")
turtlebot_len = len(turtleBotpath_points)
x = 0.0
y = 0.0
theta = 0.0
finalgoal_point = my_goal
final_turtle_x_desired = float(finalgoal_point[1]) / 100
final_turtle_y_desired = (380 - float(finalgoal_point[0])) / 100
#for itj in range(turtlebot_len):
print ("Final Desired is " + str(final_turtle_x_desired) + " y " + str(final_turtle_y_desired))
path_counter = 0
reached_bot = False
x = 0.0
y = 0.0
theta = 0.0

pub = rospy.Publisher("/Xs_Ys_ToFuzzy", Pose, queue_size = 1)
pose_msg = Pose()
Control_Input = Twist()
r = rospy.Rate(10)
goal = Point()


#######################################################
############# K A L M A N__P A R T_Start ##############
#######################################################
## Method used to transform from Euler coordinates to Quaternion coordinates
def euler_to_quaternion(yaw, pitch, roll):
    x = np.sin(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) - np.cos(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
    y = np.cos(roll/2) * np.sin(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.cos(pitch/2) * np.sin(yaw/2)
    z = np.cos(roll/2) * np.cos(pitch/2) * np.sin(yaw/2) - np.sin(roll/2) * np.sin(pitch/2) * np.cos(yaw/2)
    w = np.cos(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
    return [x, y, z, w]
## Method used to transform from Quaternion coordinates to Euler coordinates
def quaternion_to_euler(x, y, z, w):
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(t0, t1)
    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    pitch = math.asin(t2)
    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(t3, t4)
    return [yaw, pitch, roll]
    
#################Create arrays for printing#############
XModel = [] #Array to hold value of x obtained by the sensor
YModel = [] #Array to hold value of y obtained by the sensor
ThetaModel = [] #Array to hold value of theta obtained by the sensor

XNoisy = [] #Array to hold noisy value of x coordinates
YNoisy = [] #Array to hold noisy value of y coordinates
ThetaNoisy = [] #Array to hold noisy value of theta coordinates

XFiltered = [] #Array to hold Filtered value of x coordinates
YFiltered = [] #Array to hold Filtered value of y coordinates


ThetaFiltered = [] #Array to hold Filtered value of theta coordinates

TimeTotal = []

#ROS Subscriber Code for Position
flag_cont = 0			#Initialize flag by zero
pos_msg = Pose()		#Identify msg variable of data type Pose
position = np.zeros((1,6))	#Identify array of six elements all initialized by zero
Velocity_msg = Twist()		#Identify msg variable of data type Twist
velocity = np.zeros((1,6))	#Identify array of six elements all initialized by zero
Time = 0

#Callback function which is called when a new message of type Pose is received by the subscriber
def callback(data):
	  global pos_msg	#Identify msg variable created as global variable
	  global sub2		#Identify a subscriber as global variable
	  
	  #Identify all variables as globals 
	  global flag_cont
	  global position 
	  global Velocity_msg
	  global velocity
	  global Time

	  msg = data ##Extract the data sent as message

	  pos_msg.position.x = round(msg.pose.pose.position.x, 4)		#Round the value of x to 4 decimal places
	  pos_msg.position.y = round(msg.pose.pose.position.y, 4)		#Round the value of y to 4 decimal places
	  pos_msg.position.z = round(msg.pose.pose.position.z, 4)		#Round the value of y to 4 decimal places
	  pos_msg.orientation.x = round(msg.pose.pose.orientation.x, 4)		#Round the value of theta to 4 decimal places
	  pos_msg.orientation.y = round(msg.pose.pose.orientation.y, 4)		#Round the value of theta to 4 decimal places
	  pos_msg.orientation.z = round(msg.pose.pose.orientation.z, 4)		#Round the value of theta to 4 decimal places
	  pos_msg.orientation.w = round(msg.pose.pose.orientation.w, 4)		#Round the value of theta to 4 decimal places
	  [yaw, pitch, roll] = quaternion_to_euler(pos_msg.orientation.x, pos_msg.orientation.y, pos_msg.orientation.z, pos_msg.orientation.w) #Transform from Quaternion to Euler coordinates
	  ## Another way to transform from Quaternion to Euler
	  ## (roll, pitch, yaw) = tf.transformations.euler_from_quaternion([pos_msg.orientation.x, pos_msg.orientation.y, pos_msg.orientation.z, pos_msg.orientation.w]) #Transform Quaternian to Euler angles
	  position = [pos_msg.position.x,pos_msg.position.y,pos_msg.position.z,yaw, pitch, roll] ##Store the position in array

	  Velocity_msg.linear.x = round(msg.twist.twist.linear.x, 4)		#Round the value of x to 4 decimal places
	  Velocity_msg.linear.y = round(msg.twist.twist.linear.y, 4)		#Round the value of y to 4 decimal places
	  Velocity_msg.linear.z = round(msg.twist.twist.linear.z, 4)		#Round the value of z to 4 decimal places
	  Velocity_msg.angular.x = round(msg.twist.twist.angular.x, 4)		#Round the value of x to 4 decimal places
	  Velocity_msg.angular.y = round(msg.twist.twist.angular.y, 4)		#Round the value of y to 4 decimal places
	  Velocity_msg.angular.z = round(msg.twist.twist.angular.z, 4)		#Round the value of z to 4 decimal places
	  velocity = [Velocity_msg.linear.x,Velocity_msg.linear.y,Velocity_msg.linear.z,Velocity_msg.angular.x,Velocity_msg.angular.y,Velocity_msg.angular.z]##Store the velocity in array
	  
	  Time = msg.header.stamp.to_sec() 	#Extract the time of the simulation
	  flag_cont = 1				#Set flag to one

sub2 = rospy.Subscriber('/Odom_Values', Odometry, callback)
#ROS Subscriber Code for Initial Position
pos_msg_0 = Pose()	      #Identify msg variable of data type Pose
position_0 = np.zeros((1,6))  #Identify array of six elements all initialized by zero
flag_initial = 0	      #Initialize flag by zero
Velocity_msg_0 = Twist()      #Identify msg variable of data type Pose
velocity_0 = np.zeros((1,6))  #Identify array of six elements all initialized by zero
Time_0 = 0
#Callback function which is called when a new message of type Pose is received by the subscriber 
def callback_Init(data):
	  global pos_msg_0		#Identify msg variable created as global variable
	  global sub1			#Identify a subscriber as global variable

	  #Identify all variables as globals 
	  global flag_initial 	
	  global position_0 
	  global Velocity_msg_0
	  global velocity_0
	  global Time_0

	  msg = data ##Extract the data sent as message

	  pos_msg_0.position.x = round(msg.pose.pose.position.x, 4)		#Round the value of x to 4 decimal places
	  pos_msg_0.position.y = round(msg.pose.pose.position.y, 4)		#Round the value of y to 4 decimal places
	  pos_msg_0.position.z = round(msg.pose.pose.position.z, 4)		#Round the value of y to 4 decimal places
	  pos_msg_0.orientation.x = round(msg.pose.pose.orientation.x, 4)	#Round the value of theta to 4 decimal places
	  pos_msg_0.orientation.y = round(msg.pose.pose.orientation.y, 4)	#Round the value of theta to 4 decimal places
	  pos_msg_0.orientation.z = round(msg.pose.pose.orientation.z, 4)	#Round the value of theta to 4 decimal places
	  pos_msg_0.orientation.w = round(msg.pose.pose.orientation.w, 4)	#Round the value of theta to 4 decimal places
	  [yaw, pitch, roll] = quaternion_to_euler(pos_msg.orientation.x, pos_msg.orientation.y, pos_msg.orientation.z, pos_msg.orientation.w)#Transform from Quaternion to Euler coordinates
	  ## Another way to transform from Quaternion to Euler
	  ## (roll, pitch, yaw) = tf.transformations.euler_from_quaternion([pos_msg.orientation.x, pos_msg.orientation.y, pos_msg.orientation.z, pos_msg.orientation.w]) #Transform Quaternian to Euler angles
	  position_0 = [pos_msg.position.x,pos_msg.position.y,pos_msg.position.z,yaw, pitch, roll]##Store the position in array

	  Velocity_msg_0.linear.x = round(msg.twist.twist.linear.x, 4)		#Round the value of x to 4 decimal places
	  Velocity_msg_0.linear.y = round(msg.twist.twist.linear.y, 4)		#Round the value of y to 4 decimal places
	  Velocity_msg_0.linear.z = round(msg.twist.twist.linear.z, 4)		#Round the value of z to 4 decimal places
	  Velocity_msg_0.angular.x = round(msg.twist.twist.angular.x, 4)	#Round the value of x to 4 decimal places
	  Velocity_msg_0.angular.y = round(msg.twist.twist.angular.y, 4)	#Round the value of y to 4 decimal places
	  Velocity_msg_0.angular.z = round(msg.twist.twist.angular.z, 4)	#Round the value of z to 4 decimal places
	  velocity_0 = [Velocity_msg_0.linear.x,Velocity_msg_0.linear.y,Velocity_msg_0.linear.z,Velocity_msg_0.angular.x,Velocity_msg_0.angular.y,Velocity_msg_0.angular.z]##Store the velocity in array
	  
	  Time_0 = msg.header.stamp.to_sec()

	  flag_initial = 1			#Set the flag to one
	  sub1.unregister()			#Unsubsribe from this topic

sub1 = rospy.Subscriber('/Odom_Values', Odometry, callback_Init)
##Hold code here till subscribe the first msg of the vehicle position
while flag_initial == 0:
  pass
## Prediction stage in Kalman filter 
#####################################i will add equation for y and theta
##
def kf_prediction(Xprev,Pprev, A, Q, B, U):
    Xpredicted = np.matmul(A, Xprev) + np.dot(B, U)			##Predicted state vector			
    
    Ppredicted = np.matmul(A, np.matmul(Pprev, np.transpose(A))) + Q	##Predicted error co-variance matrix
    ##print("iam 	Xpredicted" + str(Xpredicted))
    return (Xpredicted, Ppredicted)  
## Correction stage in Kalman filter
#####################################i will add equation for y and theta
##
def kf_correction(Xpredicted, Ppredicted, C, Z, R):			
    CTrans = np.transpose(C)				
    num = np.matmul(Ppredicted, CTrans)		##Numerature of Kalman gain equation
    den1 = np.matmul(C, Ppredicted) 		##CMatrix * PMatrix
    den2 = np.matmul(den1, CTrans) + R  	##CMatrix * PMatrix * CMatrix^T _+ R
    den = np.matrix(den2)  			##Place denemrature in matrix form  
    deninv = den.getI()				##(CMatrix * PMatrix * CMatrix^T _+ R) Inverse 	
    KGain = np.matmul(num, deninv) 		##Calculate the Kalman gain
    ##print("KG" + str(KGain))
    Xfiltered = Xpredicted + np.matmul(KGain, (Z - np.matmul(C, Xpredicted))) 	##Estimated updated state vector
    Pfiltered = Ppredicted - np.matmul(KGain, np.matmul(C, Ppredicted)) 	##Estimated updated error co-variance matrix
    return (Xfiltered, Pfiltered)
def kf_prediction_Y(prev_Y,Pprev_Y, A, Q, B, U):
    predicted_Y = np.matmul(A, prev_Y) + np.dot(B, U)			##Predicted state vector			
    
    Ppredicted_Y = np.matmul(A, np.matmul(Pprev_Y, np.transpose(A))) + Q	##Predicted error co-variance matrix
    ##print("iam 	predicted_Y" + str(predicted_Y))
    return (predicted_Y, Ppredicted_Y)

## Correction stage in Kalman filter
#####################################i will add equation for y and theta
##
def kf_correction_Y(predicted_Y, Ppredicted_Y, C, Z, R):			
    CTrans = np.transpose(C)				
    num = np.matmul(Ppredicted_Y, CTrans)		##Numerature of Kalman gain equation
    den1 = np.matmul(C, Ppredicted_Y) 		##CMatrix * PMatrix
    den2 = np.matmul(den1, CTrans) + R  	##CMatrix * PMatrix * CMatrix^T _+ R
    den = np.matrix(den2)  			##Place denemrature in matrix form  
    deninv = den.getI()				##(CMatrix * PMatrix * CMatrix^T _+ R) Inverse 	
    KGain = np.matmul(num, deninv) 		##Calculate the Kalman gain
    ##print("KG" + str(KGain))
    Y_filtered = predicted_Y + np.matmul(KGain, (Z - np.matmul(C, predicted_Y))) 	##Estimated updated state vector
    PFiltered_Y = Ppredicted_Y - np.matmul(KGain, np.matmul(C, Ppredicted_Y)) 	##Estimated updated error co-variance matrix
    return (Y_filtered, PFiltered_Y)
def kf_prediction_Theta(Prev_Theta,PPrev_Theta, A, Q, B, U):
    Predicted_Theta = np.matmul(A, Prev_Theta) + np.dot(B, U)	##Predicted state vector			
    
    Ppredicted_Theta = np.matmul(A, np.matmul(PPrev_Theta, np.transpose(A))) + Q ##Predicted error co-variance matrix
    ##print("iam 	Predicted_Theta" + str(Predicted_Theta))
    return (Predicted_Theta, Ppredicted_Theta)
    
    
    
## Correction stage in Kalman filter
#####################################i will add equation for y and theta
##
def kf_correction_Theta(Predicted_Theta, Ppredicted_Theta, C, Z, R):			
    CTrans = np.transpose(C)				
    num = np.matmul(Ppredicted_Theta, CTrans)		##Numerature of Kalman gain equation
    den1 = np.matmul(C, Ppredicted_Theta) 		##CMatrix * PMatrix
    den2 = np.matmul(den1, CTrans) + R  	##CMatrix * PMatrix * CMatrix^T _+ R
    den = np.matrix(den2)  			##Place denemrature in matrix form  
    deninv = den.getI()				##(CMatrix * PMatrix * CMatrix^T _+ R) Inverse 	
    KGain = np.matmul(num, deninv) 		##Calculate the Kalman gain
    ##print("KG" + str(KGain))
    Filtered_Theta = Predicted_Theta + np.matmul(KGain, (Z - np.matmul(C, Predicted_Theta))) 	##Estimated updated state vector
    Pfiltered_Theta = Ppredicted_Theta - np.matmul(KGain, np.matmul(C, Ppredicted_Theta)) 	##Estimated updated error co-variance matrix
    return (Filtered_Theta, Pfiltered_Theta)

######################################################################
##                            Initialization                        ##
######################################################################
P = [[100,0,0],[0,100,0],[0,0,1]]		##Error co-variance matrix P (3x3)
Q = [[0.01,0,0],[0,0.01,0],[0,0,0.01]]		##Process noise matrix Q (3x3)
R = 0.1						##Measurement noise matrix R (1x1)

U = [[0.2],[0]]					##Control input matrix U (2x1)
X = [[0],[0],[0]]				##Initial state X (3x1)

A = [[1,0,0],[0,1,0],[0,0,1]]		##State transition matrix A (3x3) [[1,0,0],[0,1,0],[0,0,1]]	
B = [[0.1,0],[0,0],[0,0.1]]			##Input matrix B (3x2)
#C = [[1,0,0],[1,0,0],[0,0,0]]			##Input matrix C (3x3)
C = [[1,0,0]]					##Measurement matrix C (1x3)
Krho = 0.3
Kalpha = 0.3
Kbeta = -0.1
goal.x=  (20+float(turtleBotpath_points[path_counter][0])) / 100 ##Re-scaling fox x as strart in gazebo is from 0.5 of X
goal.y=  (425-float(turtleBotpath_points[path_counter][1])) / 100 ##Re-Scaling as 0.5 in gazebo equates 350 in input image in Y
print ("Temp goal is " + str(goal.x) + " y " + str(goal.y))




while (sqrt((x - final_turtle_x_desired )**2+(y - final_turtle_y_desired)**2) > 0.1)  :
	if not rospy.is_shutdown() :
     	    if (sqrt((x - goal.x )**2+(y - goal.y)**2) > 0.1) :
		#print ("Loop goal is " + str(goal.x) + " y " + str(goal.y))
        	if flag_initial == 1:			
##Get the initial states
            		X_Previous=0									
            		Y_Previous = 0
            		Theta_Previous = 0
                    	t = Time_0
            		X = [[X_Previous],[Y_Previous],[Theta_Previous]] 	##Set the states of the system
			Z = X_Previous
            		
            		(Xpredicted, Ppredicted) = kf_prediction(X, P, A, Q, B, U)			
			##Get the predicted states
            		(Xfiltered, Pfiltered) = kf_correction(Xpredicted, Ppredicted, C, Z , R)
			Z = Y_Previous
            		
            		(predicted_Y, Ppredicted_Y) = kf_prediction_Y(X, P, A, Q, B, U)			
			##Get the predicted states
            		(Y_filtered, PFiltered_Y) = kf_correction_Y(predicted_Y, Ppredicted_Y, C, Z , R)	
			##Get the corrected states
			Z = Theta_Previous
            		
            		(Predicted_Theta, Ppredicted_Theta) = kf_prediction_Theta(X, P, A, Q, B, U)			
			##Get the predicted states
            		(Filtered_Theta, Pfiltered_Theta) = kf_correction_Theta(Predicted_Theta, Ppredicted_Theta, C, Z , R)	
			##Get the corrected states
			flag_initial = 0
                     

        	if flag_cont == 1:
                    X_Previous = position[0]
            	    Y_Previous = position[1]
 
            	    Theta_Previous = position[5]##incase of my way to control i worked with Position[5] to catch noisy Theta
		    ##print("iam 	Theta P" + str(Theta_Previous))  
                    Z = X_Previous  ##Set the sensor reading for the x position of the robot

                    t = Time	##Get the time in seconds

                    X = Xfiltered	##Update the states with the filtered states
                    P = Pfiltered	##Update the error co-variance matrix

                    (Xpredicted, Ppredicted) = kf_prediction(X, P, A, Q, B, U)##Get the predicted states
                    (Xfiltered, Pfiltered) = kf_correction(Xpredicted, Ppredicted, C, Z, R)##Get the corrected states
                    ######################## For Y 
		    Z = Y_Previous  ##Set the sensor reading for the x position of the robot

                    t = Time##Get the time in seconds

                    X = Y_filtered	##Update the states with the filtered states
                    P = PFiltered_Y	##Update the error co-variance matrix
		    (predicted_Y, Ppredicted_Y) = kf_prediction_Y(X, P, A, Q, B, U)##Get the predicted states
                    (Y_filtered, PFiltered_Y) = kf_correction_Y(predicted_Y, Ppredicted_Y, C, Z, R)##Get the corrected states
		    ######################## For Theta 
                    Z = Theta_Previous  ##Set the sensor reading for the x position of the robot

                    t = Time	##Get the time in seconds

                    X = Filtered_Theta	##Update the states with the filtered states
                    P = Pfiltered_Theta	##Update the error co-variance matrix
		    (Predicted_Theta, Ppredicted_Theta) = kf_prediction_Theta(X, P, A, Q, B, U)	##Get the predicted states
                    (Filtered_Theta, Pfiltered_Theta) = kf_correction_Theta(Predicted_Theta, Ppredicted_Theta, C, Z, R)	##corrected states
		    flag_cont = 0
        #variable for controller x here is the curr x robot from filtered x 
        #variable for controller y here is the curr y robot from filtered y 
                    x = Xfiltered.item(0)##current filtered x to controller 
                    y = Y_filtered.item(0)##same as x but in y value
		    theta = Filtered_Theta.item(0)##same as x but in theta value

                    XModel.append(Xpredicted.item(0)) 	#Array to hold value of x obtained by the sensor
                    YModel.append(predicted_Y.item(0)) 	#Array to hold value of y obtained by the sensor
                    ThetaModel.append(Predicted_Theta.item(0)) 	#Array to hold value of theta obtained by the sensor
        
                    XNoisy.append(X_Previous) 			#Array to hold noisy value of x coordinates
                    YNoisy.append(Y_Previous) 			#Array to hold noisy value of y coordinates
                    ThetaNoisy.append(Theta_Previous)		#Array to hold noisy value of theta coordinates

                    XFiltered.append(Xfiltered.item(0)) 	#Array to hold Filtered value of x coordinates
                    YFiltered.append(Y_filtered.item(0))	#Array to hold Filtered value of y coordinates
                    ThetaFiltered.append(Filtered_Theta.item(0)) #Array to hold Filtered value of theta coordinates

                    TimeTotal.append(t)
        
                    #print("iam 	X filtered" + str(x))   
                    #print("iam 	Y filtered" + str(y)) 
		    #print("iam 	Theta filtered" + str(theta))

                    pose_msg.position.x = x  
                    pose_msg.position.y = y   
                    pose_msg.position.z = goal.x # Since robot will not move in Z axis ,i will exploit this to publish on it goal .x
                    pose_msg.orientation.x = theta  
                    pose_msg.orientation.y = 0
                    
                    pose_msg.orientation.w = goal.y # Since robot will not use it, i will exploit this to publish on it goal .y
                    pub.publish(pose_msg)
                    r.sleep()
 
 
     	    else : 
		if (path_counter+1 < turtlebot_len ) : 
		     path_counter = path_counter + 1
		elif (path_counter+1 >= turtlebot_len ) :
		     pose_msg.orientation.z = 1  
		     pub.publish(pose_msg)
                     r.sleep()
		     break
		goal.x = (20+float(turtleBotpath_points[path_counter][0])) / 100 #Temp Goal x in Output BFS array Re-scale
		goal.y =(425-float(turtleBotpath_points[path_counter][1])) / 100 #Temp Goal y in Output BFS array Re-scale
		print("i almost reached shifting goals to " + str(goal.x) + " " + str(goal.y))
    		pass
print ("Finished , Destination Reached !! ")
rospy.signal_shutdown("for plotting")
##Plotting of signals from sensor and noisy signals
plt.figure(1)
line_1 = plt.plot(XModel, 'r-', label='X-Model')
line_2 = plt.plot(XNoisy, 'b-', label='X-Noisy')
line_3 = plt.plot(XFiltered, 'g-', label='X-Filtered')
plt.legend()


plt.figure(2)
line_1 = plt.plot(YModel, 'r-', label='Y-Model')
line_2 = plt.plot(YNoisy, 'b-', label='Y-Noisy')
line_3 = plt.plot(YFiltered, 'g-', label='Y-Filtered')
plt.legend()

plt.figure(3)
line_1 = plt.plot(ThetaModel, 'r-', label='Theta-Model')
line_2 = plt.plot(ThetaNoisy, 'b-', label='Theta-Noisy')
line_3 = plt.plot(ThetaFiltered, 'g-', label='Theta-Filtered')
plt.legend()


plt.show(block=True)
#######################################################
############# K A L M A N__P A R T_END ##############
#######################################################    
