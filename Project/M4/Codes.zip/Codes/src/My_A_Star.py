#!/usr/bin/env python
import numpy as np
from multiprocessing import Queue
import sys
import time
import rospy
from PIL import Image
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import Point, Twist
import cv2 #import openCV to python
import sys #import sys for extracting input from termminal (input from user)
from math import atan2
from math import sqrt
class CELL():
    def __init__(self, parent=None, position=None):
        self.parent = parent
        self.position = position

        self.from_the_start_dis = 0
        self.heuristic_distance = 0
        self.fn_obj = 0
    def __eq__(self, other):
        return self.position == other.position

    
img = cv2.imread('/home/saher/catkin_ws/src/Mile4_T2/src/Input.png')  #Read image 
grayImage = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) #Convert RGB image to grayscale
ret, bw_img = cv2.threshold(grayImage,0,255,cv2.THRESH_BINARY) #Convert grayscale image to binary

bw_img = bw_img.astype(np.uint8)
print(type(bw_img))
#test image Lecture
#bw_img = np.array([
#                  [255, 255, 255, 0,   255, 255], 
#	           [255, 255, 255, 0,   255, 255],
#         	   [255, 0,   255, 0,   255, 255],
#		   [255, 0,   255, 0,   255, 255],
#	  	   [255, 0,   255, 255, 255, 255],
#	           [255, 0,   255, 255, 255, 255]])


h, w= bw_img.shape #get image dimenssions
print('height:', h)
print('width:', w)

#Check if the image is grayscale or binary
flag = 0
for i in range(1, h):
	for j in range(1,w):
		if bw_img[i,j] > 0 and bw_img[i,j] < 255:
			flag = 1;

if flag == 1:
	print('image is grayscale')
else:
	print('image is binary')

#########################################################################################################

print('press any point on image to selest the start and goal point')
#cv2.imshow("image", bw_img)
#cv2.waitKey(0) #Maintain output window until user presses a key 
#cv2.destroyAllWindows() #Destroying present windows on screen



rospy.init_node("A_Star_mycontroller")


x_Start = int(rospy.get_param("~x_Start"))	   #recieve x_Start input type casted as int
y_Start = int(rospy.get_param("~y_Start"))	   #recieve y_Start input type casted as int
x_Goal = int(rospy.get_param("~x_Goal"))   #recieve x_Goal input type casted as int
y_Goal = int(rospy.get_param("~y_Goal"))	   #recieve y_Goal input type casted as int


print('My x_Start',x_Start)
print('My y_Start',y_Start)
print('My x_Goal',x_Goal)
print('My y_Goal',y_Goal)

	
#########################################################################################################

matrix = np.zeros((400,1000))
matrix =  np.array(bw_img)
def is_obstacle(Cell_X,Cell_Y):
    if Cell_X <= 999 and Cell_Y <= 399 :
        valu = matrix[Cell_Y,Cell_X]
        if valu == 0:
            return True
    return False
def perform_my_astar(maze, start, end):

    # Create start and end Cells
    start_node = CELL(None, start)
    start_node.from_the_start_dis =0
    start_node.heuristic_distance = 0
    start_node.fn_obj = 0
    end_node = CELL(None, end)
    end_node.from_the_start_dis = 0
    end_node.heuristic_distance = 0
    end_node.fn_obj = 0
    ro_saf_mr = 24
    # Initialize both open and closed list
    open_list = []
    closed_list = []

    # Add the start node
    open_list.append(start_node)

    # Loop until you find the end
    while len(open_list) > 0:

        # Get the current node
        current_node = open_list[0]
        current_index = 0
        for index, item in enumerate(open_list):
            if item.fn_obj < current_node.fn_obj:
                current_node = item
                current_index = index

        # Pop current off open list, add to closed list
        open_list.pop(current_index)
        closed_list.append(current_node)

        # Found the goal
        if current_node == end_node:
            path = []
            current = current_node
            while current is not None:
                path.append(current.position)
                current = current.parent
            return path[::-1] # Return reversed path

        # Generate Successors
        children = []
        for new_position in [(1, 1), (0, 1), (-1, 0), (1, 0), (-1, -1), (-1, 1), (1, -1), (0, -1)]: 

            # Get node position
            node_position = (current_node.position[0] + new_position[0], current_node.position[1] + new_position[1])

            # Make sure within range
            if node_position[0] > (len(maze) - 1) or node_position[0] < 0 or node_position[1] > (len(maze[len(maze)-1]) -1) or node_position[1] < 0:
                continue

            # Make sure walkable terrain
            nod_x = node_position[0]
            nod_y = node_position[1]
            if is_obstacle(nod_x+ro_saf_mr,nod_y+ro_saf_mr) == False and is_obstacle(nod_x+ro_saf_mr,nod_y) == False and is_obstacle(nod_x,nod_y+ro_saf_mr) == False and is_obstacle(nod_x-ro_saf_mr,nod_y-ro_saf_mr) == False and is_obstacle(nod_x-ro_saf_mr,nod_y) == False and  is_obstacle(nod_x,nod_y-ro_saf_mr) == False and is_obstacle(nod_x+ro_saf_mr,nod_y-ro_saf_mr) == False and is_obstacle(nod_x-ro_saf_mr,nod_y+ro_saf_mr) == False:
                
                            # Create new node
                new_node = CELL(current_node, node_position)
                # Append
                children.append(new_node)
                # Loop through children
                for child in children:
                    if child in open_list :
                        continue
            # Child is on the closed list
                    for closed_child in closed_list:
                        if child == closed_child:
                            continue

            # Create the f, g, and h values
                    child.from_the_start_dis = current_node.from_the_start_dis + 1
                    child.heuristic_distance = ((child.position[0] - end_node.position[0]) ** 2) + ((child.position[1] - end_node.position[1]) ** 2)
                    child.fn_obj = child.from_the_start_dis + child.heuristic_distance

            # Child is already in the open list
                    for open_node in open_list:
                        if child == open_node and child.from_the_start_dis > open_node.from_the_start_dis:
                            # go to begining of loop again if dis from  start dis is bigger
                            continue

            # Add the child to the open list
                    if child not in open_list :
                        open_list.append(child)                  
##                print(maze[node_position[0]][node_position[1]])
##                print(maze[node_position[0]][node_position[1]])
##                continue
            
            else :
                #print("obstacle at x " + str(nod_x) + "  " + str(nod_y))
                current_index +=1

start = (x_Start, y_Start)
end = (x_Goal,y_Goal)

#obstacles are 0
# free path are 1 one s
i_pic = 0
j_pic = 0

#matrix[matrix == 0] = 0 #not converted from 0 to 1 its converted to 0 and 255
# so above line remake the 0`s to 1 which is free space
# and the line below turns 255 into 0 which is obstacles
matrix[matrix ==255] = 1
matrix[matrix ==254] = 1
mytime_started = time.time() #  <========= capture time before execution
print("Starting Algorithm")
np.set_printoptions(threshold=np.inf, linewidth=np.inf)  # turn off summarization, line-wrapping
with open('xx.txt', 'w') as f:
    f.write(np.array2string(matrix))
print("Please be patient if the goal in complex area [Finding Optimal Path]")
print("Working ...")
path = perform_my_astar(matrix, start, end)# search( matrix,1, start, end) #
for target_tuple in path:
    tuple_x = target_tuple[0]
    tuple_y = target_tuple[1]
    bw_img[int(tuple_y),int(tuple_x)] = 127
end_time = time.time()#  <========= capture time after execution
print ("Goal Reached ! , Time taken to find goal : " + str(end_time-mytime_started))
im = Image.fromarray(bw_img)
im.save("/home/saher/catkin_ws/src/Mile4_T2/src/Output_A_Star.png")
print("Press any key inside that Window of output map to starting moving TurtleBOT")
cv2.imshow("Window", bw_img)
cv2.destroyAllWindows() #Destroying present windows on screen
turtleBotpath_points =path
turtlebot_len = len(path)
x = 0.0
y = 0.0
theta = 0.0

def newOdom(msg):
    global x
    global y
    global theta

    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y

    rot_q = msg.pose.pose.orientation
    (roll, pitch, theta) = euler_from_quaternion([rot_q.x, rot_q.y, rot_q.z, rot_q.w])

 

sub = rospy.Subscriber("/odom", Odometry, newOdom)
pub = rospy.Publisher("/cmd_vel", Twist, queue_size = 10)

speed = Twist()

r = rospy.Rate(10)
Krho = 0.08
Kalpha = 0.05
Kbeta = -0.05
goal = Point()
goal.x = 1.2
goal.y = 1.5
finalgoal_point = [x_Goal,y_Goal]
final_turtle_x_desired = float(finalgoal_point[1]) / 100
final_turtle_y_desired = (380 - float(finalgoal_point[0])) / 100
#for itj in range(turtlebot_len):
print ("Final Desired is " + str(final_turtle_x_desired) + " y " + str(final_turtle_y_desired))
#cv2.imshow("Window", bw_img)
#cv2.waitKey(0) #Maintain output window until user presses a key 
#cv2.destroyAllWindows() #Destroying present windows on screen
path_counter = 0
reached_bot = False

x = 0.0
y = 0.0
theta = 0.0

def newOdom(msg):
    global x
    global y
    global theta

    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y

    rot_q = msg.pose.pose.orientation
    (roll, pitch, theta) = euler_from_quaternion([rot_q.x, rot_q.y, rot_q.z, rot_q.w])


sub = rospy.Subscriber("/odom", Odometry, newOdom)
pub = rospy.Publisher("/cmd_vel", Twist, queue_size = 10)
speed = Twist()
r = rospy.Rate(10)
Krho = 0.2
Kalpha = 0.2
Kbeta = -0.1
goal = Point()
goal.x=  (50+float(turtleBotpath_points[path_counter][0])) / 100
goal.y=  (400-float(turtleBotpath_points[path_counter][1])) / 100
print ("Temp goal is " + str(goal.x) + " y " + str(goal.y))

while (sqrt((x - final_turtle_x_desired )**2+(y - final_turtle_y_desired)**2) > 0.1)  :
	if not rospy.is_shutdown() :
    	    if (sqrt((x - goal.x )**2+(y - goal.y)**2) < 0.3) :  
		if (path_counter < turtlebot_len ) : 
		     path_counter = path_counter + 1
		     print("i will increase")
		elif (path_counter >= turtlebot_len ) :  
		     break
		if (path_counter >= turtlebot_len ) :
 		     goal.x = (10+float(turtleBotpath_points[path_counter-1][0])) / 100
		     goal.y =(400-float(turtleBotpath_points[path_counter-1][1])) / 100
		     break
		goal.x = (10+float(turtleBotpath_points[path_counter][0])) / 100
		goal.y =(400-float(turtleBotpath_points[path_counter][1])) / 100
		print("i almost reached shifting goals to " + str(goal.x) + " " + str(goal.y))
    		pass
     	    else : 
		print ("Loop goal is " + str(goal.x) + " y " + str(goal.y))
		xd = goal.x -x
       	 	yd = goal.y -y
     	  	rho = sqrt((xd*xd)+(yd*yd))
        	gamma = atan2(yd, xd)
        	alpha = gamma - theta
        	beta = 0 - gamma
        	speed.linear.x = Krho*rho
        	speed.angular.z = Kalpha*alpha + Kbeta*beta
        	pub.publish(speed)
        	r.sleep()
print ("Finished My AStar")
print ("Holding on Final Point")
while not rospy.is_shutdown():
    xd = goal.x -x
    yd = goal.y -y
    rho = sqrt((xd*xd)+(yd*yd))
    gamma = atan2(yd, xd)
    alpha = gamma - theta

    beta = 0 - gamma
    speed.linear.x = Krho*rho
    speed.angular.z = Kalpha*alpha + Kbeta*beta


    pub.publish(speed)
    r.sleep()
