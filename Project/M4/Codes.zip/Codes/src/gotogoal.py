import rospy
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import Point, Twist
from math import atan2
from math import sqrt

x = 0.0
y = 0.0
theta = 0.0

def newOdom(msg):
    global x
    global y
    global theta

    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y

    rot_q = msg.pose.pose.orientation
    (roll, pitch, theta) = euler_from_quaternion([rot_q.x, rot_q.y, rot_q.z, rot_q.w])

rospy.init_node("speed_controller")

sub = rospy.Subscriber("/odom", Odometry, newOdom)
pub = rospy.Publisher("/cmd_vel", Twist, queue_size = 10)

speed = Twist()

r = rospy.Rate(10)
Krho = 0.08
Kalpha = 0.05
Kbeta = -0.05
goal = Point()
goal.x = input("Input your Goal in x: ")
goal.y = input("Input your Goal in y: ")

while not rospy.is_shutdown():
    xd = goal.x -x
    yd = goal.y -y
    rho = sqrt((xd*xd)+(yd*yd))
    gamma = atan2(yd, xd)
    alpha = gamma - theta

    beta = 0 - gamma
    speed.linear.x = Krho*rho
    speed.angular.z = Kalpha*alpha + Kbeta*beta


    pub.publish(speed)
    r.sleep()
