#!/usr/bin/env python
import numpy as np
from multiprocessing import Queue
import time
import sys
import os
import collections
from matplotlib import cm
from PIL import Image
from numpy import*
from scipy import ndimage
from PIL import Image, ImageOps
import matplotlib.pyplot as plt
import rospy
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import Point, Twist
from math import atan2
from math import sqrt
import cv2 #import openCV to python
i = -1 # are horizontal
j = 0  # are vertical
value = 0
matrix = np.zeros((400,1000))
matrix_outx = np.zeros((400,1000))


#img = Image.open('/home/saher/catkin_ws/src/Mile4_T2/src/Input.png').convert('L')
#img_inverted = ImageOps.invert(img)

#np_img = np.array(img_inverted)
#np_img[np_img == 0] = 1 #not converted from 0 to 1 its converted to 0 and 255
# so above line remake the 0`s to 1 which is free space
# and the line below turns 255 into 0 which is obstacles
#np_img[np_img ==255] = 0
#np_img[np_img ==254] = 0
#matrix = np_img
#matrix_outx = np_img



img = cv2.imread('/home/saher/catkin_ws/src/Mile4_T2/src/Input.png')  #Read image 
grayImage = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) #Convert RGB image to grayscale
ret, bw_img = cv2.threshold(grayImage,0,255,cv2.THRESH_BINARY) #Convert grayscale image to binary

bw_img = bw_img.astype(np.uint8)
matrix = bw_img
matrix_outx = bw_img
np_img = bw_img

np.set_printoptions(threshold=np.inf, linewidth=np.inf)  # turn off summarization, line-wrapping
with open('/home/saher/catkin_ws/src/Mile4_T2/src/output2D_Valid_Arry.txt', 'w') as f:
    f.write(np.array2string(np_img))               
obstacles = ""
explored = ""
def is_obstacle(Cell_X,Cell_Y):
    if Cell_X <= 999 and Cell_Y <= 399 :
        valu = matrix[Cell_Y,Cell_X]
        if valu == 0:
            return True
    return False
def is_wall_cell(Cell_X,Cell_Y):
    if Cell_X == 0 and Cell_Y > 0:
        return True
    if Cell_X > 0 and Cell_Y == 0:
        return True
    if Cell_X == 0 and Cell_Y == 0:
        return True
    return False
def is_explored_cell(Cell_X,Cell_Y):
    if "i=" + str(Cell_X) in explored and "j=" + str(Cell_Y) in explored:
        return True
    return False
def add_explored_cell(Cel_X,Cel_Y):
    global explored
    str1 = "i=" + str(Cel_X)+ ","
    str2 = "j=" + str(Cel_Y)+ ","
    exploredx = str1+str2
    explored = explored + "".join(exploredx)
    return



def implement_BFS(start_point=[],goal_point=[]):
    global matrix
    var_queue = Queue()
    start_x = start_point[0]
    start_y = start_point[1]
    end_x = goal_point[0]
    end_y = goal_point[1]
    matrix[end_x,end_y] = 8 # <===== give a flag / Higlight the goal point (enha teba 8 fe west el 0s we el 1s)
    pth_list = bfs_helper(matrix, (start_x, start_y),(end_x,end_y))
    print("type now : " + str(type(pth_list)))
    return pth_list
  
    
 
for iter in range(1):
    start_x,start_y = 0,0 # 
def bfs_helper(grid, start,goalp):
    global matrix
    queue = collections.deque([[start]])
    goal = matrix[goalp[0],goalp[1]]
    height = len(matrix)
    width = len(matrix[0])
    print("Using BFS : " + str(width) + " X "  + str(height))
    print("Goal cell changed from 1 to value '8' for only Highlighting it => " + str(goal))
    seen = set([start])
    while queue:
        path = queue.popleft()
        x, y = path[-1]
        if grid[y][x] == goal:
            return path
        for x2, y2 in ((x,y+1) , (x,y-1), (x-1,y),(x+1,y),(x-1,y-1),(x+1,y+1),(x+1,y-1),(x-1,y+1)):
            if 0 <= x2 < width and 0 <= y2 < height and is_wall_cell(x2,y2)==False and is_obstacle(x2+24,y2+24)==False and is_obstacle(x2,y2+24)==False and is_obstacle(x2+24,y2)==False and is_obstacle(x2-24,y2)==False and is_obstacle(x2,y2-24)==False and is_obstacle(x2+24,y2-24)==False and is_obstacle(x2-24,y2+24)==False and (x2, y2) not in seen:
                queue.append(path + [(x2, y2)])
                seen.add((x2, y2))

#============================ MAIN BFS CALL ==========================
#++++++++++++++++++++++++++++
#=====================================================================
#=====================================================================
rospy.init_node("BFS_controller")
BFSstart = time.time() #  <========= capture time before execution
startx = rospy.get_param("~x_Start")
my_start = [int(startx), int(rospy.get_param("~y_Start"))] # giving start position i,j    <=======================================    start point
 #Sampling Time
my_goal = [int(rospy.get_param("~y_Goal")), int(rospy.get_param("~x_Goal"))]  #[40, 640] # giving end position j,i<=======================================    goal point

path_arry_list = implement_BFS(my_start,my_goal) #<=================================== needed BFS method takes start and goal points only
turtleBotpath_points =  path_arry_list
length = len(path_arry_list)

print('============== Given Path Using BFS ==============')

for ipj in range(length):
    x_path = path_arry_list[ipj][0]
    y_path = path_arry_list[ipj][1]
    matrix_outx[y_path,x_path] = 0 
    print(" move in j : " +str(y_path) + " then " + "move in i : " +str(x_path) ) 
matrix_outx[matrix_outx == 4] = 1  
matrix_outx[matrix_outx >4] = 130
BFSend = time.time()#  <========= capture time after execution
print ("Goal Reached ! , Time taken to find goal : " + str(BFSend-BFSstart))
np.set_printoptions(threshold=np.inf, linewidth=np.inf)

im = Image.fromarray(matrix_outx*255)
im.save("/home/saher/catkin_ws/src/Mile4_T2/src/Output_BFS.png")
#=========================================BFS Writer==================================
with open('/home/saher/catkin_ws/src/Mile4_T2/src/path_out_BFS.txt', 'w') as f:
    f.write(np.array2string(matrix_outx)) 
print ("Path Drawn from start to goal which cell value is '8'")
print ("Path saved to 'Output_BFS.png' in same Dir of .py file If On Windows")
turtlebot_len = len(turtleBotpath_points)
x = 0.0
y = 0.0
theta = 0.0

def newOdom(msg):
    global x
    global y
    global theta

    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y

    rot_q = msg.pose.pose.orientation
    (roll, pitch, theta) = euler_from_quaternion([rot_q.x, rot_q.y, rot_q.z, rot_q.w])

 

sub = rospy.Subscriber("/odom", Odometry, newOdom)
pub = rospy.Publisher("/cmd_vel", Twist, queue_size = 10)

speed = Twist()

r = rospy.Rate(10)
Krho = 0.08
Kalpha = 0.05
Kbeta = -0.05
goal = Point()
goal.x = 1.2
goal.y = 1.5
finalgoal_point = my_goal
final_turtle_x_desired = float(finalgoal_point[1]) / 100
final_turtle_y_desired = (380 - float(finalgoal_point[0])) / 100
#for itj in range(turtlebot_len):
print ("Final Desired is " + str(final_turtle_x_desired) + " y " + str(final_turtle_y_desired))

path_counter = 0
reached_bot = False

x = 0.0
y = 0.0
theta = 0.0

def newOdom(msg):
    global x
    global y
    global theta

    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y

    rot_q = msg.pose.pose.orientation
    (roll, pitch, theta) = euler_from_quaternion([rot_q.x, rot_q.y, rot_q.z, rot_q.w])


sub = rospy.Subscriber("/odom", Odometry, newOdom)
pub = rospy.Publisher("/cmd_vel", Twist, queue_size = 10)
speed = Twist()
r = rospy.Rate(10)
Krho = 0.2
Kalpha = 0.2
Kbeta = -0.1
goal = Point()
goal.x=  (50+float(turtleBotpath_points[path_counter][0])) / 100
goal.y=  (425-float(turtleBotpath_points[path_counter][1])) / 100
print ("Temp goal is " + str(goal.x) + " y " + str(goal.y))
while (sqrt((x - final_turtle_x_desired )**2+(y - final_turtle_y_desired)**2) > 0.3)  :
	if not rospy.is_shutdown() :
    	    if (sqrt((x - goal.x )**2+(y - goal.y)**2) < 0.3) :  
		if (path_counter < turtlebot_len ) : 
		     path_counter = path_counter + 1
		elif (path_counter >= turtlebot_len ) :  
		     break

		goal.x = (10+float(turtleBotpath_points[path_counter][0])) / 100
		goal.y =(400-float(turtleBotpath_points[path_counter][1])) / 100
		print("i almost reached shifting goals to " + str(goal.x) + " " + str(goal.y))
    		pass
     	    else : 
		print ("Loop goal is " + str(goal.x) + " y " + str(goal.y))
		xd = goal.x -x
       	 	yd = goal.y -y
     	  	rho = sqrt((xd*xd)+(yd*yd))
        	gamma = atan2(yd, xd)
        	alpha = gamma - theta
        	beta = 0 - gamma
        	speed.linear.x = Krho*rho
        	speed.angular.z = Kalpha*alpha + Kbeta*beta
        	pub.publish(speed)
        	r.sleep()
print ("Finished")
print ("Holding")
while not rospy.is_shutdown():
    xd = goal.x -x
    yd = goal.y -y
    rho = sqrt((xd*xd)+(yd*yd))
    gamma = atan2(yd, xd)
    alpha = gamma - theta

    beta = 0 - gamma
    speed.linear.x = Krho*rho
    speed.angular.z = Kalpha*alpha + Kbeta*beta


    pub.publish(speed)
    r.sleep()

